export default class ProfileField {
	container: HTMLElement;
	constructor(){
		this.container = document.createElement('div');
	}
}
